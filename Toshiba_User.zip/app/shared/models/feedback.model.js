"use strict";
var FeedbackModel = (function () {
    function FeedbackModel() {
    }
    return FeedbackModel;
}());
exports.FeedbackModel = FeedbackModel;
var MarkRelevance = (function () {
    function MarkRelevance() {
    }
    return MarkRelevance;
}());
exports.MarkRelevance = MarkRelevance;
var ActualFeedbackModel = (function () {
    function ActualFeedbackModel() {
    }
    return ActualFeedbackModel;
}());
exports.ActualFeedbackModel = ActualFeedbackModel;
var ResponseRef = (function () {
    function ResponseRef() {
    }
    return ResponseRef;
}());
exports.ResponseRef = ResponseRef;
var HoldFileData = (function () {
    function HoldFileData() {
    }
    return HoldFileData;
}());
exports.HoldFileData = HoldFileData;
//# sourceMappingURL=feedback.model.js.map