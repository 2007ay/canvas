export class DragDrop {
    file?:File;
    classname? : string = '';
}