"use strict";
var DragDrop = (function () {
    function DragDrop() {
        this.classname = '';
    }
    return DragDrop;
}());
exports.DragDrop = DragDrop;
//# sourceMappingURL=search.model.js.map