"use strict";
var SegmentModel = (function () {
    function SegmentModel() {
    }
    return SegmentModel;
}());
exports.SegmentModel = SegmentModel;
var SelectedSegmentModel = (function () {
    function SelectedSegmentModel(x, y) {
        this.segmentedUrl = x;
        this.active = y;
    }
    return SelectedSegmentModel;
}());
exports.SelectedSegmentModel = SelectedSegmentModel;
var ResponseRef = (function () {
    function ResponseRef() {
    }
    return ResponseRef;
}());
exports.ResponseRef = ResponseRef;
var ActualSegmentModel = (function () {
    function ActualSegmentModel() {
    }
    return ActualSegmentModel;
}());
exports.ActualSegmentModel = ActualSegmentModel;
//# sourceMappingURL=segment.model.js.map