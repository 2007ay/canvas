"use strict";
var TokenData = (function () {
    function TokenData() {
    }
    return TokenData;
}());
exports.TokenData = TokenData;
//# sourceMappingURL=loginData.model.js.map