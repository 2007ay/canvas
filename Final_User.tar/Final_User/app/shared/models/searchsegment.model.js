"use strict";
var SearchSegmentModel = (function () {
    function SearchSegmentModel() {
        this.segmentedUrls = [];
    }
    return SearchSegmentModel;
}());
exports.SearchSegmentModel = SearchSegmentModel;
//# sourceMappingURL=searchsegment.model.js.map