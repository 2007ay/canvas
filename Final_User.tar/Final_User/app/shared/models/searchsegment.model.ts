export class SearchSegmentModel{
    queryImageUrl: string;
    preprocessedImageUrl: string;    
    segmentedUrls: string[]=[];
	  classname: string;
    
  }