export class TokenData
{
    access_token?: string;
    token_type?: string;
    expires_in?: string;
    scope?: string;
    role?:string;
    username?: string;
    
}